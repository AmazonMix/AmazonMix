window.AMAZONMIX_PRODUCTS = [
  {
    asin: "REPLACE-ASIN-001",
    title: "Add your first Amazon product",
    description: "Replace this starter product with an approved Amazon Special Link or Creators API item.",
    category: "tech",
    image: "",
    price: "",
    amazonUrl: "",
    tags: ["Setup", "Amazon"],
    salesChannel: "amazon"
  },
  {
    asin: "REPLACE-ASIN-002",
    title: "Creator gear collection",
    description: "Starter slot for microphones, lighting, cameras and accessories.",
    category: "creator",
    image: "",
    price: "",
    amazonUrl: "",
    tags: ["Creator"],
    salesChannel: "amazon"
  },
  {
    asin: "REPLACE-ASIN-003",
    title: "Home upgrade collection",
    description: "Starter slot for useful home products.",
    category: "home",
    image: "",
    price: "",
    amazonUrl: "",
    tags: ["Home"],
    salesChannel: "amazon"
  },
  {
    asin: "REPLACE-ASIN-004",
    title: "Everyday essentials",
    description: "Starter slot for practical everyday products.",
    category: "everyday",
    image: "",
    price: "",
    amazonUrl: "",
    tags: ["Everyday"],
    salesChannel: "amazon"
  }
];

// Direct-sale example:
// {
//   asin: "EXM-001", title: "ExitosMix Product", category: "everyday",
//   price: "$19.99", image: "assets/example.jpg",
//   stripePaymentLink: "https://buy.stripe.com/REPLACE",
//   salesChannel: "exitosmix"
// }
