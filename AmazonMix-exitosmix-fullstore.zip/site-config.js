window.AMAZONMIX_CONFIG = {
  brandName: "AmazonMix",
  companyName: "ExitosMix",
  siteUrl: "https://exitosmix.com",
  amazonMarketplace: "www.amazon.com",
  amazonCreatorHubUrl: "https://www.amazon.com/creatorhub/manage",
  amazonStorefrontUrl: "",

  // Public website endpoint for Amazon product search.
  // Set this after deploying worker/amazon-worker.js.
  amazonWorkerUrl: "",

  // Supabase browser-safe public values only.
  supabaseUrl: "",
  supabaseAnonKey: "",

  // Optional newsletter endpoint.
  newsletterEndpoint: "",

  // Optional direct-sale products only.
  stripe: {
    enabled: false,
    // Example: https://buy.stripe.com/...
    paymentLinkExample: ""
  }
};
