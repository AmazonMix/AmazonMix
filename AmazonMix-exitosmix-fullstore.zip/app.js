(() => {
  const cfg = window.AMAZONMIX_CONFIG || {};
  const products = window.AMAZONMIX_PRODUCTS || [];

  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];

  function escapeHTML(value = "") {
    return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }

  function getFavorites() {
    try { return JSON.parse(localStorage.getItem("amazonmix_favorites") || "[]"); }
    catch { return []; }
  }

  function saveFavorites(favs) {
    localStorage.setItem("amazonmix_favorites", JSON.stringify(favs));
    renderFavoriteState();
    document.dispatchEvent(new CustomEvent("amazonmix:favorites-changed"));
  }

  function toggleFavorite(product) {
    const favs = getFavorites();
    const idx = favs.findIndex(x => x.asin === product.asin);
    if (idx >= 0) favs.splice(idx, 1);
    else favs.push({asin: product.asin, title: product.title, description: product.description, category: product.category, image: product.image, price: product.price, amazonUrl: product.amazonUrl});
    saveFavorites(favs);
  }

  function affiliateLabel() {
    return '<span class="affiliate-label">Paid link</span>';
  }

  function productCard(product) {
    const fav = getFavorites().some(x => x.asin === product.asin);
    const hasLink = !!product.amazonUrl;
    const img = product.image
      ? `<img src="${escapeHTML(product.image)}" alt="" loading="lazy" referrerpolicy="no-referrer">`
      : `<div class="product-placeholder"><span>AM</span><small>Add Amazon image</small></div>`;
    let shop;
    if (product.salesChannel === "exitosmix" && product.stripePaymentLink) {
      shop = `<a class="btn btn-primary small" href="${escapeHTML(product.stripePaymentLink)}" target="_blank" rel="noopener">Buy securely ↗</a>`;
    } else if (hasLink) {
      shop = `<a class="btn btn-primary small" href="${escapeHTML(product.amazonUrl)}" target="_blank" rel="nofollow sponsored noopener">Shop on Amazon ↗</a>`;
    } else {
      shop = `<a class="btn btn-muted small" href="products.html#setup">Add product link</a>`;
    }
    return `<article class="product-card">
      <div class="product-media">${img}<button class="save-btn ${fav ? "saved" : ""}" data-save="${escapeHTML(product.asin)}" aria-label="${fav ? "Remove from" : "Save"} favorites">${fav ? "♥" : "♡"}</button></div>
      <div class="product-body">
        <div class="tag-row">${affiliateLabel()} ${product.category ? `<span class="pill">${escapeHTML(product.category)}</span>` : ""}</div>
        <h3>${escapeHTML(product.title)}</h3>
        <p>${escapeHTML(product.description || "")}</p>
        <div class="product-footer">${product.price ? `<strong>${escapeHTML(product.price)}</strong>` : `<span class="tiny-note">Price at Amazon</span>`}${shop}</div>
      </div>
    </article>`;
  }

  function renderGrid(target, list) {
    if (!target) return;
    target.innerHTML = list.map(productCard).join("");
    $$("[data-save]", target).forEach(btn => btn.addEventListener("click", () => {
      const product = products.find(p => p.asin === btn.dataset.save);
      if (product) toggleFavorite(product);
    }));
  }

  function renderFavoriteState() {
    $$("[data-save]").forEach(btn => {
      const fav = getFavorites().some(x => x.asin === btn.dataset.save);
      btn.classList.toggle("saved", fav);
      btn.textContent = fav ? "♥" : "♡";
      btn.setAttribute("aria-label", `${fav ? "Remove from" : "Save"} favorites`);
    });
  }

  async function searchAmazon(query) {
    if (!cfg.amazonWorkerUrl) {
      return {configured: false, items: []};
    }
    const url = `${cfg.amazonWorkerUrl.replace(/\/$/, "")}/search?q=${encodeURIComponent(query)}`;
    const res = await fetch(url, {headers: {"Accept":"application/json"}});
    if (!res.ok) throw new Error(`Amazon search failed (${res.status})`);
    return {configured: true, items: await res.json()};
  }

  function normalizeApiItem(item) {
    return {
      asin: item.asin || "",
      title: item.title || "Amazon product",
      description: item.description || "See Amazon for current product details.",
      category: "amazon",
      image: item.image || "",
      price: item.price || "",
      amazonUrl: item.amazonUrl || "",
      tags: ["Amazon"]
    };
  }

  const featured = $("#featured-grid");
  if (featured) renderGrid(featured, products.slice(0, 4));

  const grid = $("#product-grid");
  let currentFilter = new URLSearchParams(location.search).get("category") || "all";
  if (grid) {
    const filterButtons = $$(".filter-btn");
    filterButtons.forEach(b => b.classList.toggle("active", b.dataset.filter === currentFilter));
    renderGrid(grid, currentFilter === "all" ? products : products.filter(p => p.category === currentFilter));
    filterButtons.forEach(b => b.addEventListener("click", () => {
      currentFilter = b.dataset.filter;
      filterButtons.forEach(x => x.classList.toggle("active", x === b));
      renderGrid(grid, currentFilter === "all" ? products : products.filter(p => p.category === currentFilter));
    }));
  }

  const searchForm = $("#product-search-form");
  if (searchForm) {
    searchForm.addEventListener("submit", async e => {
      e.preventDefault();
      const q = $("#product-search").value.trim();
      const status = $("#search-status");
      if (!q) {
        renderGrid(grid, currentFilter === "all" ? products : products.filter(p => p.category === currentFilter));
        status.textContent = "";
        return;
      }
      status.textContent = cfg.amazonWorkerUrl ? "Searching Amazon…" : "Amazon API not connected yet — showing matching saved products.";
      if (!cfg.amazonWorkerUrl) {
        const local = products.filter(p => `${p.title} ${p.description} ${p.category}`.toLowerCase().includes(q.toLowerCase()));
        renderGrid(grid, local);
        return;
      }
      try {
        const result = await searchAmazon(q);
        const list = (result.items || []).map(normalizeApiItem);
        renderGrid(grid, list);
        status.textContent = list.length ? `Found ${list.length} Amazon results.` : "No results found.";
        // Bind buttons for API results.
        $$(".product-card [data-save]", grid).forEach(btn => btn.addEventListener("click", () => {
          const p = list.find(x => x.asin === btn.dataset.save);
          if (p) toggleFavorite(p);
        }));
      } catch (err) {
        console.error(err);
        status.textContent = "Amazon search is temporarily unavailable. Showing your saved collection.";
        renderGrid(grid, products);
      }
    });
  }

  const newsletterForm = $("#newsletter-form");
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", async e => {
      e.preventDefault();
      const msg = $("#newsletter-message");
      if (!cfg.newsletterEndpoint) {
        msg.textContent = "Newsletter form is ready. Connect an email provider before launch.";
        return;
      }
      try {
        const email = $("#email").value.trim();
        const res = await fetch(cfg.newsletterEndpoint, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({email})});
        if (!res.ok) throw new Error();
        msg.textContent = "You're on the list.";
        newsletterForm.reset();
      } catch {
        msg.textContent = "We couldn't complete that request. Please try again later.";
      }
    });
  }

  $$(".menu-toggle").forEach(button => button.addEventListener("click", () => {
    const nav = button.closest(".nav");
    nav.classList.toggle("open");
  }));

  $("#year") && ($("#year").textContent = new Date().getFullYear());
})();
