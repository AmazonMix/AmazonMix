# AmazonMix deployment — Cloudflare Pages + Supabase

## A. Supabase

1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase.sql`.
3. In **Authentication → URL Configuration**, set:
   - Site URL: `https://exitosmix.com`
   - Redirect URL: `https://exitosmix.com/profile.html`
   - Redirect URL: `https://www.exitosmix.com/profile.html`
4. From **Project Settings → API**, copy:
   - Project URL
   - Publishable/anon browser key
5. Put those two public values in `site-config.js`.

The browser key is intended to be public; the database is protected by RLS.
Never place a Supabase service-role key in the website.

## B. Cloudflare Pages

1. Create a GitHub repository, e.g. `amazonmix-exitosmix`.
2. Upload this project to the repository.
3. In Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git.
4. Select the repository.
5. Framework preset: **None**.
6. Build command: leave blank.
7. Build output directory: `/` (the repository root).
8. Deploy.

Cloudflare can automatically redeploy on pushes to the connected repository.

## C. Connect exitosmix.com

In the Pages project:
Workers & Pages → your project → Custom domains → Set up a domain → `exitosmix.com`.

For an apex domain, Cloudflare requires the domain to be a Cloudflare zone and the domain's nameservers to point to Cloudflare. Cloudflare will then create the Pages CNAME record.

Add both:
- `exitosmix.com`
- `www.exitosmix.com`

Pick `https://exitosmix.com` as the canonical URL for the site, then redirect `www` to the apex if desired.

## D. Customer profiles

Supabase Auth is already wired into `profile.html` / `profile.js`.
The profile page supports:
- email + password signup
- email + password login
- logout
- saved AmazonMix favorites
- synchronization of favorites to Supabase

Email confirmation is controlled by your Supabase Auth settings. Supabase's JavaScript client persists sessions in the browser by default.

## E. Amazon product connection

Amazon's current Creators API onboarding requires:
- an Amazon Associates account
- final acceptance into the Associates Program
- an Associate tag
- Creators API application credentials

Do not put the Amazon client secret in the website.
Deploy `worker/amazon-worker.js` as a Cloudflare Worker and store these Worker secrets:
- `AMAZON_CLIENT_ID`
- `AMAZON_CLIENT_SECRET`
- `AMAZON_PARTNER_TAG`

Then set `amazonWorkerUrl` in `site-config.js`.

Until API access is active, use approved Amazon Special Links from SiteStripe and place them in `products-data.js`.

## F. Direct online payments

For Amazon affiliate items, customers complete checkout on Amazon.

For products that ExitosMix directly sells and fulfills, create Stripe Payment Links and add them as:
`stripePaymentLink: "https://buy.stripe.com/..."`,
with:
`salesChannel: "exitosmix"`.

This starter then shows a **Buy securely** button that opens Stripe-hosted checkout. Stripe Payment Links can accept cards, debit cards and mobile wallets without you storing card numbers.

## G. Final pre-launch checks

- Test signup, email confirmation and login.
- Test saving/removing favorites on two browsers.
- Test `exitosmix.com` and `www.exitosmix.com`.
- Test every Amazon Special Link.
- Confirm affiliate disclosure is visible.
- Replace the starter legal pages with your final policies.
- Add your actual customer-support contact and business information.
- Confirm direct-sale tax, shipping, returns and refund rules before selling your own products.
