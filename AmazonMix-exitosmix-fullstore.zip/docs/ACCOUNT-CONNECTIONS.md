# Account connections still requiring the owner

These are account credentials/actions that cannot be created safely on your behalf:

## Cloudflare
Create/login to Cloudflare, add `exitosmix.com`, then connect the Pages project to GitHub.

## Supabase
Create a project and run `supabase.sql`, then paste the public Project URL and browser key into `site-config.js`.

## Amazon
Your Amazon Associates account must be accepted before Creators API registration. Amazon then issues the tag / credentials through Associates Central.

## Stripe (optional)
Create Stripe Payment Links only for products ExitosMix is authorized to sell directly. Paste those links into direct-sale product entries.
