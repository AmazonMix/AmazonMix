(() => {
  const cfg = window.AMAZONMIX_CONFIG || {};
  const supabaseReady = !!(cfg.supabaseUrl && cfg.supabaseAnonKey && window.supabase);
  const supabase = supabaseReady ? window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey) : null;

  const $ = s => document.querySelector(s);
  let mode = "login";
  const authCard = $("#auth-card"), profileCard = $("#profile-card"), message = $("#auth-message");

  function localFavs() {
    try { return JSON.parse(localStorage.getItem("amazonmix_favorites") || "[]"); } catch { return []; }
  }

  function renderLocalProfile() {
    const favs = localFavs();
    $("#favorite-count").textContent = favs.length;
    const grid = $("#favorites-grid");
    grid.innerHTML = favs.map(p => {
      const image = p.image ? `<img src="${p.image}" alt="" loading="lazy">` : `<div class="product-placeholder"><span>AM</span></div>`;
      return `<article class="product-card compact-card"><div class="product-media">${image}</div><div class="product-body"><h3>${p.title}</h3><div class="product-footer"><span></span>${p.amazonUrl ? `<a class="btn btn-primary small" href="${p.amazonUrl}" target="_blank" rel="nofollow sponsored noopener">Shop ↗</a>` : ""}</div></div></article>`;
    }).join("");
    $("#empty-favorites").classList.toggle("hidden", favs.length > 0);
  }

  async function loadSession() {
    if (!supabase) {
      message.textContent = "Profile login is ready but not connected. Add your Supabase URL and anon key in site-config.js.";
      return;
    }
    const {data:{session}} = await supabase.auth.getSession();
    if (session) await showProfile(session.user);
  }

  async function showProfile(user) {
    authCard.classList.add("hidden");
    profileCard.classList.remove("hidden");
    const name = user.user_metadata?.display_name || user.email?.split("@")[0] || "Customer";
    $("#profile-heading").textContent = `Hi, ${name}`;
    $("#profile-email-text").textContent = user.email || "";
    $("#profile-avatar").textContent = name.slice(0,2).toUpperCase();
    if (!supabase) return renderLocalProfile();

    const {data, error} = await supabase.from("favorites").select("*").eq("user_id", user.id).order("created_at", {ascending:false});
    if (!error) {
      localStorage.setItem("amazonmix_favorites", JSON.stringify((data || []).map(x => ({
        asin:x.asin,title:x.title,description:x.description||"",category:x.category||"amazon",
        image:x.image||"",price:x.price||"",amazonUrl:x.amazon_url||""
      }))));
    }
    renderLocalProfile();
  }

  async function syncFavoriteToCloud(fav) {
    if (!supabase) return;
    const {data:{user}} = await supabase.auth.getUser();
    if (!user) return;
    await supabase.from("favorites").upsert({
      user_id: user.id, asin: fav.asin, title: fav.title, description: fav.description || "",
      category: fav.category || "amazon", image: fav.image || "", price: fav.price || "", amazon_url: fav.amazonUrl || ""
    });
  }

  const $$ = (s) => [...document.querySelectorAll(s)];

  $$(".tab").forEach(tab => tab.addEventListener("click", () => {
    mode = tab.dataset.mode;
    $$(".tab").forEach(x => x.classList.toggle("active", x === tab));
    $("#name-wrap").classList.toggle("hidden", mode !== "signup");
    $("#auth-submit").textContent = mode === "signup" ? "Create account" : "Log in";
  }));

  $("#auth-form").addEventListener("submit", async e => {
    e.preventDefault();
    message.textContent = "";
    if (!supabase) {
      message.textContent = "Connect Supabase first. The UI is installed and waiting for your project credentials.";
      return;
    }
    const email = $("#profile-email").value.trim();
    const password = $("#profile-password").value;
    try {
      if (mode === "signup") {
        const display_name = $("#profile-name").value.trim() || "Customer";
        const {data,error} = await supabase.auth.signUp({email,password,options:{data:{display_name}}});
        if (error) throw error;
        if (data.session) await showProfile(data.user);
        else message.textContent = "Account created. Check your email to confirm your address.";
      } else {
        const {data,error} = await supabase.auth.signInWithPassword({email,password});
        if (error) throw error;
        await showProfile(data.user);
      }
    } catch (err) {
      message.textContent = err.message || "Unable to sign in.";
    }
  });

  $("#logout-btn").addEventListener("click", async () => {
    if (supabase) await supabase.auth.signOut();
    profileCard.classList.add("hidden");
    authCard.classList.remove("hidden");
  });

  document.addEventListener("amazonmix:favorites-changed", async () => {
    if (!supabase) return;
    const favs = localFavs();
    for (const fav of favs) await syncFavoriteToCloud(fav);
    renderLocalProfile();
  });

  loadSession();
})();
