# AmazonMix — ExitosMix starter storefront

This package is a production-oriented starter for **https://exitosmix.com**.

## What is already included

- Responsive AmazonMix storefront design
- Product browsing and search UI
- Amazon affiliate disclosure
- Amazon product-card structure (ASIN/title/image/price/affiliate URL)
- Customer login/signup profile UI
- Favorites saved locally, with Supabase sync when connected
- Supabase SQL schema with row-level security
- Cloudflare Worker template for Amazon Creators API product search
- Creator Hub shortcut
- Legal starter pages
- Custom-domain `CNAME`
- No Amazon credentials stored in frontend files

## Important checkout rule

For Amazon affiliate products, the shopper should be sent to Amazon to complete the purchase. Amazon controls checkout, payment, shipping, returns and the final order. Do **not** collect payment on AmazonMix for an Amazon product simply because you linked to it as an affiliate.

For products that ExitosMix is authorized to sell directly, you can enable a separate direct-sales flow using a hosted processor such as Stripe. That is a different business flow and needs its own fulfillment, refund, tax, privacy and terms setup.

## Configuration

Edit `site-config.js`:

```js
window.AMAZONMIX_CONFIG = {
  siteUrl: "https://exitosmix.com",
  amazonCreatorHubUrl: "https://www.amazon.com/creatorhub/manage",
  amazonStorefrontUrl: "",
  amazonWorkerUrl: "",
  supabaseUrl: "",
  supabaseAnonKey: ""
};
```

Do not put `AMAZON_CLIENT_SECRET` or other Amazon secrets in this file.

## Amazon products

### Simple/manual method
Until your Amazon Creators API access is active, use Amazon SiteStripe / approved affiliate tools to make Special Links and paste them into `products-data.js`.

Replace:
- `asin`
- `title`
- `description`
- `image`
- `price` (optional)
- `amazonUrl` (your Amazon Special Link)

Keep the Amazon-required affiliate disclosure visible.

### Automated method
The `worker/amazon-worker.js` file is designed to run as a Cloudflare Worker. Put Amazon credentials into Worker secrets and point `amazonWorkerUrl` to the deployed Worker URL.

Amazon's current Creators API documentation says Associates must have an accepted Associates account before registering for Creators API access, and the API is used for catalog lookups such as SearchItems / GetItems. Verify your eligibility and current terms in Amazon Associates Central before deploying.

## Customer accounts with Supabase

1. Create a Supabase project.
2. Run `supabase.sql` in the Supabase SQL Editor.
3. Add the project's URL and public anon key to `site-config.js`.
4. In Supabase Auth settings, add:
   - `https://exitosmix.com/profile.html`
   - `https://www.exitosmix.com/profile.html`
   - your Cloudflare Pages preview URL during development.

The site never needs an Amazon customer password.

## Hosting: easiest low-cost path

### Option A — Cloudflare Pages (recommended)
1. Put this folder in a GitHub repository.
2. In Cloudflare, create a Pages project from that repo.
3. Deploy the site as a static site (no build step needed).
4. Add `exitosmix.com` and `www.exitosmix.com` under Custom Domains.
5. If using the apex domain, put your domain on Cloudflare by changing nameservers as Cloudflare instructs.
6. HTTPS is handled by Cloudflare.

Cloudflare's current Pages documentation lists a Free plan and supports custom domains. See:
https://developers.cloudflare.com/pages/configuration/custom-domains/

### Option B — GitHub Pages
GitHub Pages is free on GitHub Free for supported repositories and supports custom domains. See:
https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

For the customer-account version of this site, keep card/payment data off GitHub Pages and use hosted services (Supabase + Stripe or Amazon checkout).

### Amazon Content Partners
Amazon currently advertises a US-focused Content Partners program with free hosting benefits including AWS Lightsail credits for eligible websites. Treat this as an optional Amazon-native hosting route, subject to eligibility and Amazon's current terms.

## Payments

Stripe can be added for products you sell yourself. Payment Links use pay-as-you-go processing; Stripe currently advertises pricing starting at 2.9% + 30¢ per successful charge. The checkout page can be Stripe-hosted, so AmazonMix does not need to store card details.

Do not use Stripe to masquerade as Amazon checkout for affiliate listings.

## Domain

The included `CNAME` file is:

```text
exitosmix.com
```

## Launch checklist

- [ ] Verify your Amazon Associates / Influencer status.
- [ ] Add your actual Amazon Special Links or approved Creators API connection.
- [ ] Confirm affiliate disclosures are visible.
- [ ] Create and configure Supabase.
- [ ] Deploy to Cloudflare Pages.
- [ ] Connect `exitosmix.com`.
- [ ] Test mobile layout.
- [ ] Test login/signup and favorites.
- [ ] Test every Amazon link.
- [ ] Add your final privacy/terms text and any cookie/analytics disclosures.
- [ ] Add direct payment only for products you are authorized to sell directly.
