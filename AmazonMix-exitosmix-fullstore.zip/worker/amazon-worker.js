/**
 * AmazonMix Cloudflare Worker
 *
 * Environment variables / Worker secrets:
 *   AMAZON_CLIENT_ID
 *   AMAZON_CLIENT_SECRET
 *   AMAZON_CREDENTIAL_VERSION (example: 3.1)
 *   AMAZON_PARTNER_TAG (example: yourtag-20)
 *
 * This keeps your Amazon credential secret off the public website.
 *
 * The worker exposes:
 *   GET /search?q=headphones
 *
 * Before launch, confirm your Amazon Associates + Creators API access and
 * review Amazon's current API/program terms.
 */

let tokenCache = {token: null, expiresAt: 0};

const TOKEN_URL = "https://api.amazon.com/auth/o2/token";
const API_URL = "https://creatorsapi.amazon/catalog/v1/searchItems";
const MARKETPLACE = "www.amazon.com";

async function getToken(env) {
  const now = Date.now();
  if (tokenCache.token && tokenCache.expiresAt > now + 60_000) return tokenCache.token;

  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: env.AMAZON_CLIENT_ID,
    client_secret: env.AMAZON_CLIENT_SECRET,
    scope: "creatorsapi::default"
  });

  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: {"Content-Type": "application/x-www-form-urlencoded"},
    body
  });
  if (!res.ok) throw new Error(`Amazon auth failed: ${res.status}`);
  const data = await res.json();
  tokenCache = {token: data.access_token, expiresAt: now + (Number(data.expires_in || 3600) * 1000)};
  return tokenCache.token;
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type"
    }
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return json({ok:true});
    if (url.pathname !== "/search") return json({error:"Not found"}, 404);

    const q = (url.searchParams.get("q") || "").trim();
    if (!q) return json({error:"Missing q"}, 400);

    if (!env.AMAZON_CLIENT_ID || !env.AMAZON_CLIENT_SECRET || !env.AMAZON_PARTNER_TAG) {
      return json({error:"Amazon credentials are not configured on the worker."}, 503);
    }

    try {
      const token = await getToken(env);
      const body = {
        partnerTag: env.AMAZON_PARTNER_TAG,
        keywords: q,
        marketplace: MARKETPLACE,
        itemCount: 10,
        resources: [
          "images.primary.medium",
          "itemInfo.title",
          "offersV2.listings.price"
        ]
      };

      const res = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
          "x-marketplace": MARKETPLACE
        },
        body: JSON.stringify(body)
      });

      if (!res.ok) return json({error:"Amazon catalog request failed", status:res.status}, res.status);
      const data = await res.json();

      const items = data?.searchResult?.items || [];
      const normalized = items.map(item => ({
        asin: item.asin || "",
        title: item.itemInfo?.title?.displayValue || "Amazon product",
        image: item.images?.primary?.medium?.url || item.images?.primary?.small?.url || "",
        price: item.offersV2?.listings?.[0]?.price?.displayAmount || "",
        amazonUrl: item.detailPageURL || ""
      }));

      return json(normalized);
    } catch (err) {
      return json({error: err.message || "Unexpected error"}, 500);
    }
  }
};
